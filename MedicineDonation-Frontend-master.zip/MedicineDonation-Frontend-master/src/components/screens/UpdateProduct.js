import { Image, StyleSheet, Text, TouchableOpacity, View, ScrollView, ActivityIndicator } from 'react-native';
import React, { useContext, useState } from 'react';
import { Formik } from "formik";
import { TextInput } from 'react-native-paper';
import ErrorText from './components/ErrorText';
import { launchImageLibrary } from 'react-native-image-picker';
import getFileExtension from '../../../utils/getFileExtension';
import MEDICINE from "../../../assets/medicinedonation-logo.png";
import DatePicker from 'react-native-date-picker';
import SweetAlert from 'react-native-sweet-alert';
import updateMedicine from '../../../services/updateMedicine';
import { UserContext } from '../../../global/UserContext';

const UpdateProductScreen = ({ route }) => {
    const [user] = useContext(UserContext);
    const [loading, setLoading] = useState(false);

    let { donation } = route.params || {};

    const handleUpdate = async (values) => {
        setLoading(true)
        let body = !values.quantity ?
            { ...values, stock: donation.quantity, price: values.mg, category: "Medicine" } :
            { ...values, price: values.mg, stock: values.quantity,  category: "Medicine"}
        let nb = {
            name: body.name,
            date: body.date,
            price: body.price,
            description: body.description,
            category: body.category,
            stock: body.stock,
            seller: user.name
        }
        const [, error] = await updateMedicine(nb, donation._id);
        if (error) {
            console.log(error.response)
            setLoading(false)
            return SweetAlert.showAlertWithOptions({
                title: 'Cant Update Medicine',
                subTitle: 'Failed to Update Medicine',
                confirmButtonTitle: 'OK',
                confirmButtonColor: 'red',
                otherButtonTitle: 'Cancel',
                otherButtonColor: '#dedede',
                style: 'danger',
                cancellable: true,
            });
        }
        setLoading(false);
        SweetAlert.showAlertWithOptions({
            title: 'Successfully Update Medicine',
            subTitle: '',
            confirmButtonTitle: 'OK',
            confirmButtonColor: 'red',
            otherButtonTitle: 'Cancel',
            otherButtonColor: '#dedede',
            style: 'success',
            cancellable: true,
        });
    }

    const handleImage = async (setFieldValue) => {
        const { didCancel, assets } = await launchImageLibrary(
            { mediaType: 'photo', includeBase64: true });
        if (didCancel) return;
        const extension = getFileExtension(assets[0].fileName);
        let imageBase64 = `data:image/${extension};base64,` + assets[0].base64;
        setFieldValue("images", imageBase64);
    }

    if (loading) return <View style={{ width: '100%', height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size={"large"} color='orange' />
    </View>
    return (
        <ScrollView style={styles.main}>
            <Image style={styles.img} source={MEDICINE} />
            <Text style={styles.header}>Update Medicine</Text>
            <Formik
                initialValues={{
                    name: donation?.name || '',
                    mg: donation?.mg || '',
                    description: donation?.description || '',
                    images: donation?.images[0]?.url || 'https://image.shutterstock.com/image-photo/beauty-woman-face-portrait-beautiful-260nw-488715607.jpg',
                    quantity: donation?.stock || '',
                    date: new Date()
                }}
                onSubmit={handleUpdate}
            >
                {({ handleSubmit, handleChange, errors, values, setFieldValue, touched, setFieldTouched }) => <View style={styles.form}>
                    <TextInput
                        label={"Name"}
                        mode="outlined"
                        value={values.name}
                        error={errors.name}
                        onChangeText={handleChange("name")}
                        onBlur={() => setFieldTouched("name")}
                        theme={{ colors: { primary: 'orange', text: 'orange' } }}
                    />
                    <ErrorText error={errors.name} touched={touched.name} />
                    <View style={{borderWidth: 1, borderColor: 'black', padding: 10, marginTop:10}}>
            <Text style={{ color: 'black', fontSize: 20, fontWeight: 'bold', padding: 10, }}>Expiry Date: </Text>
                    <DatePicker date={values.date} onDateChange={(t) => setFieldValue("date", t)} />
                    </View>
                    <TextInput
                        label={"mg"}
                        mode="outlined"
                        value={values.mg.toString()}
                        error={errors.mg}
                        onChangeText={handleChange("mg")}
                        onBlur={() => setFieldTouched("mg")}
                        theme={{ colors: { primary: 'orange', text: 'orange' } }}
                    />
                    <ErrorText error={errors.mg} touched={touched.mg} />
                    <TextInput
                        label={"Description"}
                        mode="outlined"
                        value={values.description}
                        error={errors.description}
                        onChangeText={handleChange("description")}
                        onBlur={() => setFieldTouched("description")}
                        theme={{ colors: { primary: 'orange', text: 'orange' } }}
                        multiline
                        numberOfLines={10}
                    />
                    <ErrorText error={errors.description} touched={touched.description} />
                    <TextInput
                        label={"Quantity"}
                        mode="outlined"
                        error={errors.quantity}
                        value={values.quantity.toString()}
                        onChangeText={handleChange("quantity")}
                        onBlur={() => setFieldTouched("quantity")}
                        theme={{ colors: { primary: 'orange', text: 'orange' } }}
                    />
                    <ErrorText error={errors.quantity} touched={touched.quantity} />
                    <View style={styles.imageField}>
                        <TouchableOpacity onPress={() => handleImage(setFieldValue)}>
                            <Image source={{ uri: values.images }} style={styles.image} />
                        </TouchableOpacity>
                        <Text style={styles.imageText}>Select An Image</Text>
                        <TouchableOpacity style={styles.choose} onPress={() => handleImage(setFieldValue)}>
                            <Text style={styles.chooseText}>Choose</Text>
                        </TouchableOpacity>
                    </View>
                    <TouchableOpacity style={styles.btn} onPress={handleSubmit}>
                        <Text style={styles.btnText}>Update Medicine</Text>
                    </TouchableOpacity>
                </View>}
            </Formik>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    main: {
        height: '100%',
        backgroundColor: 'white'
    },
    form: {
        padding: 10
    },
    imageField: {
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10
    },
    image: {
        width: 60,
        height: 60,
        borderRadius: 70,
        borderWidth: 1,
        borderColor: 'orange',
    },
    imageText: {
        marginLeft: 20,
        color: 'black'
    },
    choose: {
        backgroundColor: 'gray',
        padding: 15,
        borderRadius: 15,
        marginLeft: 20
    },
    chooseText: {
        color: 'white'
    },
    btn: {
        backgroundColor: 'orange',
        padding: 15,
        marginTop: 20
    },
    btnText: {
        textAlign: 'center',
        color: 'white',
        fontWeight: 'bold'
    },
    img: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: 150,
        width: 150,
        marginLeft: '30%'
    },
    header: {
        textAlign: 'center',
        fontSize: 22,
        fontWeight: 'bold',
        color: 'black',
        margin: 20
    }
});

export default UpdateProductScreen;

