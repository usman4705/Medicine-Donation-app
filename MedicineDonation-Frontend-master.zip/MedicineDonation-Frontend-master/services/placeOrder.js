import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BACKEND } from "@env";

const placeOrder = async(orderItems, shippingInfo) => {
    try {
        const token = await AsyncStorage.getItem("medicineToken");
        const {data} = await axios.post(
            BACKEND+"/order/new",
            {orderItems, shippingInfo},
            {headers: { Cookie: "token="+token }}
        )
        return [data, null]
    } catch (error) {
        return [null, error]
    }
}

export default placeOrder;