import {
  StyleSheet,
  Text,
  TextInput,
  View,
  ScrollView,
  TouchableOpacity,
  Image,
  ActivityIndicator
} from 'react-native';
import {useFormik} from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import SweetAlert from 'react-native-sweet-alert';
import MEDICINE from '../../../assets/medicinedonation-logo.png';
import React, {useState, useContext} from 'react';
import { UserContext } from '../../../global/UserContext';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { BACKEND } from "@env";

const Login = ({navigation}) => {
  const [loading, setLoading] = useState(false);

  const [,setUser] = useContext(UserContext);

  const validationSchema = Yup.object().shape({
    email: Yup.string().email('Enter valid email').required('Required'),
    password: Yup.string()
      .min(8, 'Password minimum length should be 8')
      .required('Required'),
  });
  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',
    },
    validationSchema: validationSchema,
    onSubmit: async values => {
      const formData = new FormData();
      formData.append('email', values.email);
      formData.append('password', values.password);
      try {
        setLoading(true);
        const {data} = await axios.post(
          BACKEND+'/login',
          {
            email: values.email,
            password: values.password,
          },
        );
        await AsyncStorage.setItem("medicineToken",data.token);
        setUser(data.user);
        SweetAlert.showAlertWithOptions({
          title: 'Successfully Logged In',
          subTitle: '',
          confirmButtonTitle: 'OK',
          confirmButtonColor: 'red',
          otherButtonTitle: 'Cancel',
          otherButtonColor: '#dedede',
          style: 'success',
          cancellable: true,
        });
      } catch (error) {
        console.log(error.response);
        setLoading(false);
        SweetAlert.showAlertWithOptions({
          title: 'Credentials Error',
          subTitle: 'Failed to Log In',
          confirmButtonTitle: 'OK',
          confirmButtonColor: 'red',
          otherButtonTitle: 'Cancel',
          otherButtonColor: '#dedede',
          style: 'danger',
          cancellable: true,
        });
      }
    },
  });

  if(loading) return <View style={{width: '100%', height: '100%', display: 'flex',justifyContent: 'center',alignItems:'center'}}>
    <ActivityIndicator size={"large"} color='orange' />
  </View>
  return (
    <ScrollView>
      <View style={styles.article}>
        <Image style={styles.img} source={MEDICINE} />
        <View style={{margin: 20}}>
          <Text style={{fontSize: 30, color: 'black', fontWeight: 'bold'}}>
            SIGN IN
          </Text>
        </View>
        <TextInput
          style={styles.input}
          placeholder="Enter Email"
          value={formik.values.email}
          onChangeText={formik.handleChange('email')}
        />
        {formik.errors.email && (
          <Text style={{fontSize: 10, color: 'red'}}>
            {formik.errors.email}
          </Text>
        )}

        <TextInput
          style={styles.input}
          value={formik.values.password}
          secureTextEntry={true}
          onChangeText={formik.handleChange('password')}
          placeholder="Enter Password"
        />
        {formik.errors.password && (
          <Text style={{fontSize: 10, color: 'red'}}>
            {formik.errors.password}
          </Text>
        )}

        <TouchableOpacity onPress={formik.handleSubmit} style={styles.btn}>
          <Text style={{color: 'white', fontWeight: 'bold'}}>LOGIN</Text>
        </TouchableOpacity>
        <Text style={{color: 'blue', textDecorationLine: 'underline'}}>
          Forgot Password ?
        </Text>
        <Text
          onPress={() => navigation.navigate('Signup')}
          style={{color: 'blue', textDecorationLine: 'underline', margin: 20}}>
          Are you new user ? Sign Up
        </Text>
      </View>
    </ScrollView>
  );
};

export default Login;

const styles = StyleSheet.create({
  article: {
    margin: 20,

    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    borderRadius: 20,
    height: 50,
    width: '70%',
    margin: 12,
    backgroundColor: 'lightgray',
    padding: 10,
  },
  btn: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#5995fd',
    height: 40,
    width: 100,
    borderRadius: 12,
    margin: 30,
  },
  img: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: 150,
    width: 150,
  },
  sectionStyle: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderWidth: 0.5,
    borderColor: 'gray',
    height: 40,
    borderRadius: 12,
    margin: 10,
  },
  imageStyle: {
    padding: 10,
    margin: 5,
    height: 25,
    width: 25,
    resizeMode: 'stretch',
    alignItems: 'center',
  },
});
