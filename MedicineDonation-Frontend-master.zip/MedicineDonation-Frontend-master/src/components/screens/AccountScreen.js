import {StyleSheet, Text, View, Image, TouchableOpacity} from 'react-native';
import React, { useContext } from 'react';
import { UserContext } from '../../../global/UserContext';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AccountScreen = ({navigation}) => {
  const [user, setUser] = useContext(UserContext);

  const handleLogout = async() => {
    setUser({})
    await AsyncStorage.removeItem("medicineToken");
  }

  return (
    <View style={styles.main}>
      <TouchableOpacity>
        <Image style={styles.image} source={{uri: user.avatar.url}}/>
      </TouchableOpacity>
      <Text style={styles.name}>{user.name}</Text>
      <Text style={styles.email}>Email: {user.email}</Text>
      <Text style={styles.phone}>Phone: {user.phone}</Text>
      <TouchableOpacity onPress={() => navigation.navigate("UpdatePassword")} style={styles.btn}>
        <Text style={styles.btnText}>Update Password</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate("UpdateProfile")} style={styles.btn}>
        <Text style={styles.btnText}>Update Profile</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate("Orders")} style={styles.btn}>
        <Text style={styles.btnText}>Orders</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={handleLogout} style={styles.btn}>
        <Text style={styles.btnText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  main: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    height:'100%'
  },
  image: {
    width: 200,
    height: 200,
    borderRadius: 200
  },
  name: {
    fontWeight: 'bold',
    fontSize: 25,
    color: 'black',
    marginBottom: 10
  },
  email: {
    fontWeight: 'bold',
    fontSize: 16,
    color: 'gray',
    marginBottom: 10
  },
  phone: {
    fontWeight: 'bold',
    fontSize: 16,
    color: 'gray',
    marginBottom: 10
  },
  btn: {
    padding: 10,
    backgroundColor: 'orange',
    width: '50%',
    borderRadius: 10,
    marginBottom: 10,
    marginTop: 10
  },
  btnText: {
    color: 'white',
    fontWeight: 'bold', 
    textAlign: 'center',
    fontSize: 16
  }
});

export default AccountScreen;

