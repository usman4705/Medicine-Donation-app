import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { TextInput, TouchableRipple } from "react-native-paper"

const Search = ({handleSearch, handleReset}) => {
    const [text, setText] = React.useState("");

    const handleText = (text) => {
        setText(text)
        if(!text) handleReset();
    }

    return (
        <>
            <View style={{ width: '100%' }}>
                <TextInput
                    label={"Search Medicines"}
                    mode='outlined'
                    value={text}
                    onChangeText={handleText}
                />
            </View>
            <TouchableRipple onPress={()=>handleSearch(text)} rippleColor='gray' borderless style={{ padding: 10, backgroundColor: 'orange', marginTop: 10, width: '50%', borderRadius: 10 }}>
                <Text style={{ textAlign: 'center', color: 'white', fontWeight: 'bold' }}>Search</Text>
            </TouchableRipple>
            <TouchableRipple onPress={handleReset} rippleColor='gray' borderless style={{ padding: 10, backgroundColor: 'orange', marginTop: 10, width: '50%', borderRadius: 10 }}>
                <Text style={{ textAlign: 'center', color: 'white', fontWeight: 'bold' }}>See All Medicines</Text>
            </TouchableRipple>
        </>
    )
}

const styles = StyleSheet.create({})

export default Search
