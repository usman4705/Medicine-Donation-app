import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BACKEND } from "@env";

const getOrders = async() => {
    try {
        const token = await AsyncStorage.getItem("medicineToken")
        if(!token) return;
        const {data} = await axios.get(
            BACKEND+'/orders/me',
            {headers: { Cookie: "token="+token }}
        )
        return [data, null]
    } catch (error) {
        return [null, error]
    }
}

export default getOrders;