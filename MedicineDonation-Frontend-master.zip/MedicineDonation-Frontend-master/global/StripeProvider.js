import React, { useContext } from 'react';
import { UserContext } from './UserContext';
import { StripeProvider as Stp } from '@stripe/stripe-react-native';


const StripeProvider = ({children}) => {
    const [user] = useContext(UserContext)

    return <Stp publishableKey={user.stripeKey}>
        {children}
    </Stp>
}

export default StripeProvider;