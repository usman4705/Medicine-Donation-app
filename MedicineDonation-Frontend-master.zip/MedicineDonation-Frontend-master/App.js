import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import UserProvider from './global/UserContext';
import Navigation from './navigation/navigation';
import CartProvider from './global/CartContext';
import StripeProvider from './global/StripeProvider';


const App = () => {
  return (
    <UserProvider>
      <CartProvider>
        <StripeProvider>
          <NavigationContainer>
            <Navigation />
          </NavigationContainer>
        </StripeProvider>
      </CartProvider>
    </UserProvider>
  );
};

export default App;
