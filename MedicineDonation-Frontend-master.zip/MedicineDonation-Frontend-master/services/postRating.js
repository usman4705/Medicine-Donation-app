import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BACKEND } from "@env";

const postRating = async(productId, comment, rating) => {
    try {
        const token = await AsyncStorage.getItem("medicineToken");
        const {data} = await axios.put(
            BACKEND+'/review',
            {productId, comment, rating},
            {headers: {Cookie: "token="+token}}
        )
        return [data, null]
    } catch (error) {
        return [null, error]
    }
}

export default postRating;