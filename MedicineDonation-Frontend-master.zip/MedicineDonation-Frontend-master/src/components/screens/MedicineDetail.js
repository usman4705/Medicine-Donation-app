import { StyleSheet, Text, View, ActivityIndicator, Image, ScrollView } from 'react-native'
import React, { useState, useRef, useEffect, useContext } from 'react'
import getMedicineById from '../../../services/getMedicineById';
import Icon from "react-native-vector-icons/MaterialIcons";
import { TouchableOpacity } from 'react-native-gesture-handler';
import { TextInput } from 'react-native-paper';
import postRating from '../../../services/postRating';
import SweetAlert from 'react-native-sweet-alert';
import { CartContext } from '../../../global/CartContext';

const MedicineDetail = ({ route }) => {
	const [details, setDetails] = useState({});
	const [loading, setLoading] = useState(true);
	const [review, setReview] = useState("");
	const [rating, setRating] = useState(1);
	const [cart, setCart] = useContext(CartContext);
	const fetchDetails = useRef(null);

	const { _id } = route.params;

	fetchDetails.current = async () => {
		const [data, error] = await getMedicineById(_id);
		setDetails(data.singleproduct);
		setLoading(false)
	}

	useEffect(() => {
		fetchDetails.current();
	}, [])

	const handleDec = () => {
		if(!details.quantity) return;
		if(details.quantity < 1) return;
		setDetails({...details, quantity: --details.quantity})
	}

	const handleInc = () => {
		if(!details.quantity)
			return setDetails({...details, quantity: 1})
		setDetails({...details, quantity: ++details.quantity})
	}

	const handleReview = async () => {
		setLoading(true)
		const [data, error] = await postRating(details._id, review, rating);
		if (error) {
			console.log(error.response)
			setLoading(false);
			return SweetAlert.showAlertWithOptions({
				title: 'Review cant be posted',
				subTitle: 'Failed to Post Review',
				confirmButtonTitle: 'OK',
				confirmButtonColor: 'red',
				otherButtonTitle: 'Cancel',
				otherButtonColor: '#dedede',
				style: 'danger',
				cancellable: true,
			});
		}
		setLoading(false)
	}

	const addToCart = () => {
		const temp = [...cart];
		const existingItem = temp.find(item => item._id === details._id);
		if (existingItem?._id) return;
		if(!details.quantity)
			temp.push({...details, quantity: 1})
		else
			temp.push({...details})
		setCart([...temp]);
		SweetAlert.showAlertWithOptions({
			title: 'Added to Cart',
			subTitle: `${details.name} was added to cart`,
			confirmButtonTitle: 'OK',
			confirmButtonColor: 'red',
			otherButtonTitle: 'Cancel',
			otherButtonColor: '#dedede',
			style: 'danger',
			cancellable: true,
		});
	}

	const Stars = () => {
		let stars = [];
		for (let i = 0; i < details.ratings; i++) {
			stars.push(
				<View>
					<Icon name="star" size={30} color="yellow" />
				</View>,
			);
		}
		return (
			<View
				style={{
					display: 'flex',
					flexDirection: 'row',
					alignItems: 'center',
				}}>
				{stars.map((item, key) => (
					<View key={key}>
						<Icon name="star" size={30} color="yellow" />
					</View>
				))}
				{details.numofReviews ? (
					<Text>{details.numofReviews} Reviews</Text>
				) : null}
			</View>
		);
	};

	const ReviewStars = ({ rating }) => {
		let stars = [];
		for (let i = 0; i < rating; i++) {
			stars.push(
				<View>
					<Icon name="star" size={30} color="yellow" />
				</View>,
			);
		}
		return (
			<View
				style={{
					display: 'flex',
					flexDirection: 'row',
					alignItems: 'center',
					marginBottom: 10
				}}>
				{stars.map((item, key) => (
					<View key={key}>
						<Icon name="star" size={20} color="yellow" />
					</View>
				))}
			</View>
		);
	}

	if (loading) return <View style={styles.loader}>
		<ActivityIndicator color={"orange"} size={40} />
	</View>
	return (
		<ScrollView style={styles.main}>
			<View style={styles.imageView}>
				<Image style={styles.image} source={{ uri: details.images[0].url }} />
			</View>
			<Text style={styles.name}>{details.name}</Text>
			<Text style={styles.id}>Product# {details._id}</Text>
			<Stars />
			<View style={styles.line}></View>
			<Text style={styles.date}>
				Expiry Date: {new Date(details.date).getFullYear() +
					'-' +
					new Date(details.date).getDay() +
					'-' +
					new Date(details.date).getMonth()}
			</Text>
			<View style={styles.cart}>
				<TouchableOpacity onPress={handleDec} style={[styles.incBtn, { backgroundColor: '#dc3545' }]}>
					<Text style={styles.incText}>-</Text>
				</TouchableOpacity>
				<Text>{details.quantity || 0}</Text>
				<TouchableOpacity onPress={handleInc} style={styles.incBtn}>
					<Text style={styles.incText}>+</Text>
				</TouchableOpacity>
				<TouchableOpacity onPress={addToCart} style={styles.addToCart}>
					<Text style={styles.addToCartText}>Add to Cart</Text>
				</TouchableOpacity>
			</View>
			<View style={styles.line}></View>
			<Text style={styles.descriptionHeader}>Description: </Text>
			<Text style={styles.description}>{details.description}</Text>
			<View style={styles.line}></View>
			<Text style={styles.descriptionHeader}>Reviews: </Text>
			{details.reviews.map(review => <>
				<View style={styles.line}></View>
				<TouchableOpacity>
					<Text style={styles.reviewName}>By: {review.name}</Text>
					<ReviewStars rating={review.rating} />
					<Text style={styles.reviewComment}>{review.comment}</Text>
				</TouchableOpacity>
				<View style={styles.line}></View>
			</>)}
			<TextInput
				label={"Review"}
				mode='outlined'
				onChangeText={text => setReview(text)}
				theme={{ colors: { primary: 'orange', text: 'orange' } }}
			/>
			<TextInput
				label={"Rate From 1-5"}
				mode='outlined'
				onChangeText={text => setRating(text)}
				error={Number.isNaN(parseInt(rating)) || parseInt(rating) > 5 || parseInt(rating) < 1}
				theme={{ colors: { primary: 'orange', text: 'orange' } }}
			/>
			<TouchableOpacity onPress={handleReview} style={[styles.addToCart, { marginTop: 10, marginBottom: 10 }]}>
				<Text style={[styles.addToCartText, { textAlign: 'center' }]}>Submit Review</Text>
			</TouchableOpacity>
			<View style={{ padding: 20 }}></View>
		</ScrollView>
	)
}

const styles = StyleSheet.create({
	main: {
		height: '100%',
		backgroundColor: 'white',
		padding: 10,
	},
	loader: {
		height: '100%',
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center'
	},
	imageView: {
		width: '100%',
		height: 350
	},
	image: {
		width: '100%',
		height: '100%'
	},
	name: {
		fontSize: 22,
		color: 'black'
	},
	id: {
		color: 'gray',
		fontSize: 16,
		fontWeight: 'bold'
	},
	line: {
		height: 1,
		backgroundColor: 'gray',
		marginTop: 10,
		marginBottom: 10
	},
	date: {
		color: 'gray',
		fontWeight: 'bold',
		fontSize: 16
	},
	cart: {
		display: 'flex',
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center'
	},
	incBtn: {
		padding: 10,
		backgroundColor: 'dodgerblue',
		borderRadius: 10,
		margin: 10
	},
	incText: {
		color: 'white',
		fontWeight: 'bold'
	},
	addToCart: {
		padding: 15,
		backgroundColor: 'orange',
		borderRadius: 25
	},
	addToCartText: {
		color: 'white',
		fontWeight: 'bold'
	},
	descriptionHeader: {
		fontWeight: 'bold',
		fontSize: 20,
		color: 'gray'
	},
	description: {
		color: 'black',
		fontSize: 16,
		textAlign: 'justify'
	},
	reviewName: {
		fontSize: 16,
		color: 'black',
		marginRight: 10,
		marginBottom: 10
	},
	reviewComment: {
		color: 'black',
		fontSize: 16,
	}
})

export default MedicineDetail
