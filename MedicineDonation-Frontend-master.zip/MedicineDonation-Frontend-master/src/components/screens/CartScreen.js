import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Image
} from 'react-native';
import React, { useContext, useState } from 'react';
import { CartContext } from '../../../global/CartContext';
import Icon from "react-native-vector-icons/AntDesign"

const CartScreen = ({navigation}) => {
  const [cart, setCart] = useContext(CartContext);
  const [sum, setSum] = useState(0);

  const handleDelete = id => {
    console.log(id)
    const temp = cart.filter(item => item._id !== id);
    setCart(temp);
  }

  const handleDec = (item) => {
    if(item.quantity < 2) return;
		let temp = cart.filter(itm => itm._id !== item._id);
    let tmp = { ...item, quantity: --item.quantity }
		temp.push(tmp)
    setCart(temp);
    setSum(prev => prev-1)
	}

	const handleInc = (item) => {
    let temp = cart.filter(itm => itm._id !== item._id);
    let tmp = { ...item, quantity: ++item.quantity }
		temp.push(tmp)
    setCart(temp);
    setSum(prev => prev+1)
	}

  if(!cart.length) return <View style={{height: '100%', flex: 1, justifyContent:'center',alignItems:'center'}}>
    <Text style={{color: 'gray',fontWeight: 'bold', fontSize: 22}}>Cart is Empty</Text>
  </View>
  return (
    <ScrollView style={styles.main}>
      {cart.map(item => <View style={styles.cartItem}>
        <TouchableOpacity>
          <Image style={styles.image} source={{ uri: item.images[0].url }} />
        </TouchableOpacity>
        <View>
          <Text style={styles.name}>{item.name}</Text>
          <View style={styles.cart}>
            <TouchableOpacity onPress={() => handleDec(item)} style={[styles.incBtn, { backgroundColor: '#dc3545' }]}>
              <Text style={styles.incText}>-</Text>
            </TouchableOpacity>
            <Text>{item.quantity || 0}</Text>
            <TouchableOpacity onPress={() => handleInc(item)} style={styles.incBtn}>
              <Text style={styles.incText}>+</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleDelete(item._id)} style={{marginLeft:10}}>
              <Icon name="delete" size={25} color="red" />
            </TouchableOpacity>
          </View>
        </View>
      </View>)}
      <View style={styles.summary}>
        <Text style={styles.orderSummaryHeader}>Order Summary</Text>
        <View style={styles.line}></View>
        <View style={styles.quantityView}>
          <Text style={styles.quantityHeader}>Quantity:</Text>
          <Text style={styles.quantity}>{cart.length+sum} units</Text>
        </View>
        <View style={styles.line}></View>
        <TouchableOpacity onPress={() => navigation.navigate("Checkout")} style={styles.btn}>
          <Text style={styles.btnText}>Check out</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  main: {
    height: '100%',
    padding: 10
  },
  cartItem: {
    display: 'flex',
    flexDirection: 'row'
  },
  line: {
    marginTop: 10,
    marginBottom: 10,
    backgroundColor: 'gray',
    height: 1
  },
  summary: {
    borderWidth: 1,
    borderRadius: 30,
    padding: 20,
    borderWidth: 1,
    borderColor: 'gray'
  },
  orderSummaryHeader: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'gray'
  },
  quantityView: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  quantityHeader: {
    color: 'gray',
    fontWeight: 'bold',
    fontSize: 16
  },
  quantity: {
    color: 'black',
    fontWeight: 'bold',
    fontSize: 16
  },
  btn: {
    backgroundColor: 'orange',
    padding: 15,
    borderRadius: 25
  },
  btnText: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 16
  },
  image: {
    width: 150,
    height: 150
  },
  cart: {
		display: 'flex',
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center'
	},
	incBtn: {
		padding: 10,
		backgroundColor: 'dodgerblue',
		borderRadius: 10,
		margin: 10
	},
	incText: {
		color: 'white',
		fontWeight: 'bold'
	},
	addToCart: {
		padding: 15,
		backgroundColor: 'orange',
		borderRadius: 25
	},
	addToCartText: {
		color: 'white',
		fontWeight: 'bold'
	},
  name: {
    marginLeft: 10,
    color: 'black'
  }
});

export default CartScreen;

