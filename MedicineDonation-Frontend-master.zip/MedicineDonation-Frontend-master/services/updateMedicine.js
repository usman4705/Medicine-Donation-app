import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BACKEND } from "@env";

const updateMedicine = async(payload, id) => {
    try {
        const token = await AsyncStorage.getItem("medicineToken")
        const {data} = await axios.put(
            BACKEND+`/admin/product/${id}`,
            payload,
            {headers: { Cookie: "token="+token }}
        )
        return [data, null]
    } catch (error) {
        return [null, error]
    }
}

export default updateMedicine;