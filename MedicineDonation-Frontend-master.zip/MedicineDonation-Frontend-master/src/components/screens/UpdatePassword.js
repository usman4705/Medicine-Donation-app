import { StyleSheet, Text, View, Image } from 'react-native'
import React, {useState} from 'react'
import { TextInput } from 'react-native-paper'
import { TouchableOpacity } from 'react-native-gesture-handler';
import updatePassword from '../../../services/updatePassword';
import SweetAlert from 'react-native-sweet-alert';
import MEDICINE from "../../../assets/medicinedonation-logo.png"

const UpdatePassword = () => {
    const [oldPassword, setOldPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");

    const handlePress = async() => {
        const [data, error] = await updatePassword(oldPassword, newPassword);
        if(data) SweetAlert.showAlertWithOptions({
            title: 'Successfully Updated',
            subTitle: '',
            confirmButtonTitle: 'OK',
            confirmButtonColor: 'red',
            otherButtonTitle: 'Cancel',
            otherButtonColor: '#dedede',
            style: 'success',
            cancellable: true,
          });
          if(error) SweetAlert.showAlertWithOptions({
            title: 'Couldnt Update Password',
            subTitle: 'Failed to Update Password',
            confirmButtonTitle: 'OK',
            confirmButtonColor: 'red',
            otherButtonTitle: 'Cancel',
            otherButtonColor: '#dedede',
            style: 'danger',
            cancellable: true,
          });
          setOldPassword("");
          setNewPassword("");
    }

  return (
    <View style={styles.main}>
        <Image style={styles.img} source={MEDICINE} />
        <Text style={styles.header}>Update Password</Text>
      <TextInput 
        label="Old Password"
        mode="outlined"
        value={oldPassword}
        theme={{colors: {primary: 'orange', text: 'orange'}}}
        onChangeText={text=>setOldPassword(text)}
        secureTextEntry
      />
      <TextInput 
        label="New Password"
        mode="outlined"
        value={newPassword}
        theme={{colors: {primary: 'orange', text: 'orange'}}}
        onChangeText={text=>setNewPassword(text)}
        secureTextEntry
      />
      <TouchableOpacity onPress={handlePress} style={styles.btn}>
        <Text style={styles.btnText}>Update Password</Text>
      </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
    main: {
        display: 'flex',
        backgroundColor: 'white',
        height: '100%',
        padding: 10,
        justifyContent: 'center'
    },
    header: {
        fontSize: 25,
        fontWeight: 'bold',
        color: 'black',
        textAlign: 'center', marginBottom:10
    },
    btn: {
        width: '100%',
        padding: 15,
        backgroundColor: 'orange',
        marginTop: 20
    },
    btnText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 16, textAlign: 'center'
    },
    img: {
        position: 'absolute',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: 150,
        width: 150,
        top: 20,
        right: '34%'
      },
})

export default UpdatePassword
