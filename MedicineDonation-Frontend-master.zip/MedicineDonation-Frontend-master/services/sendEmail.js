import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BACKEND } from "@env";

const sendEmail = async(myemail) => {
    try {
        const token = await AsyncStorage.getItem("medicineToken");
        if(!token) return [null,"No Token"]
        const {data} = await axios.post(
            BACKEND+'/email',
            {myemail},
            {headers: { Cookie: 'token='+token }}
        )
        return [data, null]
    } catch (error) {
        return [null, error]
    }
}

export default sendEmail;