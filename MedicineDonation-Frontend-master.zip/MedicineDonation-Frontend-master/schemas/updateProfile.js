import * as yup from "yup";

const updateProfileSchema = yup.object({
    name: yup
        .string()
        .notRequired(),
    email: yup
        .string()
        .email()
        .notRequired(),
    phone: yup
        .number()
        .notRequired(),
    avatar: yup
        .string()
        .notRequired()
})

export { updateProfileSchema }