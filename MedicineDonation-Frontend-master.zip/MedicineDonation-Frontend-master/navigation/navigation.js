import React, { useContext } from 'react'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import ProductScreen from '../src/components/screens/ProductScreen';
import AddProductScreen from "../src/components/screens/AddProductScreen";
import CartScreen from "../src/components/screens/CartScreen";
import AccountScreen from "../src/components/screens/AccountScreen";
import Icon from "react-native-vector-icons/MaterialIcons";
import { UserContext } from '../global/UserContext';
import Login from '../src/components/auth/Login';
import { createStackNavigator } from '@react-navigation/stack';
import Signup from '../src/components/auth/Signup';
import UpdatePassword from '../src/components/screens/UpdatePassword';
import UpdateProfile from '../src/components/screens/UpdateProfile';
import MedicineDetail from '../src/components/screens/MedicineDetail';
import Checkout from '../src/components/screens/Checkout';
import Donations from '../src/components/screens/Donations';
import UpdateProductScreen from '../src/components/screens/UpdateProduct';
import Orders from '../src/components/screens/Orders';
import OrderDetails from '../src/components/screens/OrderDetails';
import DonateMoney from '../src/components/screens/DonateMoney';

const screenOptions = (route, color) => {
  let iconName;

  switch (route.name) {
    case 'Medicines':
      iconName = 'medical-services';
      color = '#000950';
      break;
    case 'Add Medicines':
      iconName = 'add-circle';
      color = '#000950';
      break;
    case 'Cart':
      iconName = 'shopping-cart';
      color = '#000950';
      break;
    case 'Profile':
      iconName = 'account-circle';
      color = '#000950';
    default:
      break;
  }
  return <Icon name={iconName} color={color} size={30} />;
};

const AuthStack = () => {
  const Stack = createStackNavigator();

  return <Stack.Navigator
    screenOptions={() => ({
      headerShown: false
    })}
  >
    <Stack.Screen name='Login' component={Login} />
    <Stack.Screen name='Signup' component={Signup} />
  </Stack.Navigator>
}

const AccountStack = () => {
  const Stack = createStackNavigator();

  return <Stack.Navigator
    screenOptions={() => ({
      headerShown: false
    })}
  >
    <Stack.Screen name='Account' component={AccountScreen} />
    <Stack.Screen name='UpdatePassword' component={UpdatePassword} />
    <Stack.Screen name="UpdateProfile" component={UpdateProfile} />
    <Stack.Screen name="Orders" component={Orders} />
    <Stack.Screen name="OrderDetails" component={OrderDetails} />
  </Stack.Navigator>
}

const MedicineStack = () => {
  const Stack = createStackNavigator();

  return <Stack.Navigator
    screenOptions={() => ({
      headerShown: false
    })}
  >
    <Stack.Screen name='Home' component={ProductScreen} />
    <Stack.Screen name='MedicineDetail' component={MedicineDetail} />
  </Stack.Navigator>
}

const CartStack = () => {
  const Stack = createStackNavigator();

  return <Stack.Navigator
    screenOptions={() => ({
      headerShown: false
    })}
  >
    <Stack.Screen name='Main' component={CartScreen} />
    <Stack.Screen name='Checkout' component={Checkout} />
  </Stack.Navigator>
}

const DonationStack = () => {
  const Stack = createStackNavigator();

  return <Stack.Navigator
    screenOptions={() => ({
      headerShown: false
    })}
  >
    <Stack.Screen name='MainDonation' component={Donations} />
    <Stack.Screen name='Update Medicines' component={UpdateProductScreen} />
    <Stack.Screen name='DonateMoney' component={DonateMoney} />
  </Stack.Navigator>
}


const Navigation = () => {
  const [user] = useContext(UserContext);
  const Tab = createBottomTabNavigator();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color }) => screenOptions(route, color),
        tabBarStyle: { height: 70 },
        tabBarActiveTintColor: 'black',
        tabBarLabelStyle: {
          fontSize: 14,
          fontStyle: 'normal',
          fontWeight: 'bold',
        },
        activeTintColor: 'black',
        inactiveTintColor: 'grey',

        style: {
          borderTopColor: '#66666666',
          elevation: 20,
        },
        headerShown: false,
      })}>
      <Tab.Screen name="Medicines" component={MedicineStack} />
      <Tab.Screen
        options={{
          tabBarLabel: 'Donations',
          tabBarIcon: ({ color, size }) => <Icon
            name='medical-services'
            color={"#000950"}
            size={size} />
        }}
        name='Donations' component={user.email ? DonationStack: AuthStack} />
      <Tab.Screen options={{tabBarLabel: 'Add'}} name="Add Medicines" component={user.email ? AddProductScreen: AuthStack} />
      <Tab.Screen name="Cart" component={CartStack} />
      <Tab.Screen name="Profile" component={user.email ? AccountStack : AuthStack} />
    </Tab.Navigator>
  )
}

export default Navigation;