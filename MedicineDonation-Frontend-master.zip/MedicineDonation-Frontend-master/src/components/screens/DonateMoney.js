import React, { useContext, useState, useEffect, useRef } from 'react';
import { StyleSheet, TouchableOpacity, View, Text, ActivityIndicator } from "react-native";
import { UserContext } from '../../../global/UserContext';
import { CardField, useStripe, initStripe } from '@stripe/stripe-react-native';
import axios from 'axios';
import { TextInput } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SweetAlert from 'react-native-sweet-alert';
import { BACKEND } from "@env";

const DonateMoney = () => {
    const [cardDetails, setCardDetails] = useState({});
    const [donateAmount, setDonateAmount] = useState("");
    const [loading, setLoading] = useState(false);
    const [user] = useContext(UserContext);

    const { confirmPayment } = useStripe();

    const handlePayment = async () => {
        if(!cardDetails.complete) return SweetAlert.showAlertWithOptions({
            title: 'Invalid Card Details',
            subTitle: "Please Fill Carefully",
            confirmButtonTitle: 'OK',
            confirmButtonColor: 'red',
            otherButtonTitle: 'Cancel',
            otherButtonColor: '#dedede',
            style: 'danger',
            cancellable: true,
        });
        setLoading(true)
        try {
            const token = await AsyncStorage.getItem("medicineToken");
            if (!token) return;
            const paymentData = {
                amount: Math.round(donateAmount * 100)
            }
            const backendAmount = {
                amount: Math.round(donateAmount * 1)
            }

            const { data: res1 } = await axios.post(
                BACKEND + '/payment/money',
                backendAmount
                , { headers: { Cookie: "token=" + token } }
            )
            const { data: res2 } = await axios.post(
                BACKEND + '/payment/process',
                paymentData
                , { headers: { Cookie: "token=" + token } }
            )

            const client_secret = res2.client_secret;

            const { error } = await confirmPayment(client_secret, {
                paymentMethodType: 'Card',
                paymentMethodData: {
                    billingDetails: {
                        email: user.email,
                        name: user.name,
                        address: user.address
                    }
                }
            })

            if (error) {
                setLoading(false)
                return SweetAlert.showAlertWithOptions({
                    title: 'Payment Failed',
                    subTitle: error.localizedMessage,
                    confirmButtonTitle: 'OK',
                    confirmButtonColor: 'red',
                    otherButtonTitle: 'Cancel',
                    otherButtonColor: '#dedede',
                    style: 'danger',
                    cancellable: true,
                });
            }

            SweetAlert.showAlertWithOptions({
                title: 'Payment Successful',
                subTitle: '',
                confirmButtonTitle: 'OK',
                confirmButtonColor: 'red',
                otherButtonTitle: 'Cancel',
                otherButtonColor: '#dedede',
                style: 'success',
                cancellable: true,
            });
            setLoading(false)
        } catch (error) {
            console.log("Catch error")
            console.log(error.response?.data || error)
            setLoading(false)
        }
    }

    return (
        <View style={{ display: 'flex', justifyContent: 'center', padding: 20 }}>
            <Text style={{ textAlign: 'center', fontSize: 22, color: 'black', fontWeight: 'bold' }}>Donate Money</Text>
            <CardField
                placeholders={{
                    number: 'xxxx xxxx xxxx xxxx',
                }}
                cardStyle={{
                    backgroundColor: '#FFFFFF',
                    textColor: '#000000',
                }}
                style={{
                    width: '100%',
                    height: 50,
                    marginVertical: 30,
                }}
                onCardChange={(cardDetails) => {
                    console.log('cardDetails', cardDetails);
                    setCardDetails(cardDetails);
                  }}
            />
            <TextInput
                label={"Donate Amount"}
                value={donateAmount}
                onChangeText={text => setDonateAmount(text)}
                mode="outlined"
                style={{ marginBottom: 30 }}
            />
            <TouchableOpacity style={{ padding: 10, width: '100%', backgroundColor: 'orange', display: 'flex', flexDirection: 'row' }} onPress={loading? null: handlePayment}>
                <Text style={{ color: 'white', textAlign: 'center', fontWeight: 'bold' }}>Confirm Payment</Text>
                {loading && <ActivityIndicator color="white" size={20} />}
            </TouchableOpacity>
        </View>
    );
}

export default DonateMoney;
