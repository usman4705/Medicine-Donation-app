import React, { createContext, useState, useEffect, useRef } from 'react';
import refreshUser from '../services/refreshUser';
import getStripeApiKey from '../services/getStripeApiKey';

export const UserContext = createContext(null);

const UserProvider = ({children}) => {
    const [user, setUser] = useState({});
    const readUserFromStorage = useRef(null);

    readUserFromStorage.current = async() => {
        const [data, error] = await refreshUser();
        const [stripeKey, stripeKeyError] = await getStripeApiKey();
        if(stripeKeyError) return console.log(stripeKeyError.response);
        if(error) return console.log(error.response);
        setUser({...data.user, stripeKey: stripeKey.stripeApiKey});
    }

    useEffect(()=>{
        readUserFromStorage.current()
    },[])

    return <UserContext.Provider value={[user, setUser]}>
        {children}
    </UserContext.Provider>
}

export default UserProvider;