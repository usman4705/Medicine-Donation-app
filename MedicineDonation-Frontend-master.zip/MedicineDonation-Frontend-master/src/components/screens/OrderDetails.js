import { ActivityIndicator, Image, StyleSheet, Text, View, ScrollView } from 'react-native'
import React, { useState, useEffect, useRef } from 'react'
import getOrderById from '../../../services/getOrderById';

const OrderDetails = ({ route }) => {
	const [order, setOrder] = useState({})
	const [loading, setLoading] = useState(true);
	const fetchOrder = useRef(null);

	const { id } = route.params;

	fetchOrder.current = async () => {
		const [data, error] = await getOrderById(id);
		if (error) return setLoading(false);
		setOrder(data.order);
		setLoading(false);
	}

	useEffect(() => {
		fetchOrder.current();
	}, [])

	if (loading) return <View style={{ width: '100%', height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
		<ActivityIndicator size={"large"} color='orange' />
	</View>
	return (
		<ScrollView style={{ padding: 30 }}>
			<Text style={{ fontSize: 18, color: 'black', fontWeight: 'bold', marginBottom: 20 }}>
				Order #: <Text style={{ color: 'orange' }}>{order._id}</Text>
			</Text>
			<Text style={{ color: 'black', fontSize: 18, fontWeight: 'bold', marginBottom: 10 }}>Shipping Info: </Text>
			<Text style={{ fontSize: 16, color: 'black', fontWeight: 'bold' }}>Medicine :
				<Text style={{ color: 'orange' }}>{order.orderItems.map(item => item.name + "  ")}</Text>
			</Text>
			<Text style={{ fontSize: 16, color: 'black', fontWeight: 'bold' }}>Phone :
				<Text style={{ color: 'orange' }}>{order.shippingInfo.phoneNo}</Text>
			</Text>
			<Text style={{ fontSize: 16, color: 'black', fontWeight: 'bold' }}>Address :
				<Text style={{ color: 'orange' }}>{order.shippingInfo.address}</Text>
			</Text>
			<View style={{ backgroundColor: 'gray', height: 1, marginTop: 20, marginBottom: 20 }}></View>
			<Text style={{ fontSize: 16, color: 'black', fontWeight: 'bold' }}>Order Status :
				<Text style={{ color: order.orderStatus === "Processing" ? 'red' : 'green' }}>{order.orderStatus}</Text>
			</Text>
			<View style={{ backgroundColor: 'gray', height: 1, marginTop: 20, marginBottom: 20 }}></View>
			<Text style={{ fontSize: 16, color: 'black', fontWeight: 'bold' }}>Order Items :</Text>
			{order.orderItems.map(item => <View style={{ marginBottom: 10, marginTop: 10 }}>
				<Image style={{ height: 90, width: 90 }} source={{ uri: item.image }} />
				<Text style={{ fontSize: 16, color: 'black', fontWeight: 'bold' }}>Name :
					<Text style={{ color: 'orange' }}>{item.name}</Text>
				</Text>
				<Text style={{fontSize: 16, color: 'black', fontWeight: 'bold'}}>Quantity :
				<Text style={{color: 'orange'}}>{item.quantity} piece(s)</Text>
			</Text>
			</View>)}
		</ScrollView>
	)
}

export default OrderDetails