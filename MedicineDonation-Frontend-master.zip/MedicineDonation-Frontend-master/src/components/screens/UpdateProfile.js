import React, { useContext, useState } from 'react'
import { StyleSheet, Text, View, Image, ActivityIndicator } from 'react-native'
import { Formik } from 'formik';
import { TextInput } from 'react-native-paper';
import ErrorText from './components/ErrorText';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { updateProfileSchema } from '../../../schemas/updateProfile';
import { launchImageLibrary } from 'react-native-image-picker';
import getFileExtension from '../../../utils/getFileExtension';
import updateProfile from '../../../services/updateProfile';
import { UserContext } from '../../../global/UserContext';
import SweetAlert from 'react-native-sweet-alert';
import AsyncStorage from '@react-native-async-storage/async-storage';
import MEDICINE from "../../../assets/medicinedonation-logo.png"

const UpdateProfile = ({ navigation }) => {
	const [loading, setLoading] = useState(false);
	const [user, setUser] = useContext(UserContext);

	const handleSubmit = async values => {
		setLoading(true);
		let vals = {};
		Object.keys(values).map(key => values[key] !== undefined && (vals[key] = values[key]));
		const copy = { name: user.name, email: user.email, phone: user.phone }
		if(vals.avatar === user.avatar.url) vals.avatar = "";
		const [, error] = await updateProfile({ ...copy, ...vals });
		if (error) {
			setLoading(false);
			return SweetAlert.showAlertWithOptions({
				title: 'Update Failed',
				subTitle: 'Failed to Update Profile',
				confirmButtonTitle: 'OK',
				confirmButtonColor: 'red',
				otherButtonTitle: 'Cancel',
				otherButtonColor: '#dedede',
				style: 'danger',
				cancellable: true,
			});
		}
		SweetAlert.showAlertWithOptions({
			title: 'Successfully Updated',
			subTitle: '',
			confirmButtonTitle: 'OK',
			confirmButtonColor: 'red',
			otherButtonTitle: 'Cancel',
			otherButtonColor: '#dedede',
			style: 'success',
			cancellable: true,
		});
		let newVals = {}
		Object.keys(vals).map(key => key !== "avatar" && (newVals[key] = vals[key]));
		setUser({ ...user, ...newVals});
		navigation.goBack();

	}

	const handleImage = async (setFieldValue) => {
		const { didCancel, assets } = await launchImageLibrary(
			{ mediaType: 'photo', includeBase64: true });
		if (didCancel) return;
		const extension = getFileExtension(assets[0].fileName);
		let imageBase64 = `data:image/${extension};base64,` + assets[0].base64;
		setFieldValue("avatar", imageBase64);
	}

	if (loading) return <View style={styles.loader}>
		<ActivityIndicator color={"orange"} size={40} />
	</View>
	return (
		<View style={styles.main}>
			<Image style={styles.img} source={MEDICINE} />
			<Text style={styles.header}>Update Profile</Text>
			<Formik
				initialValues={{
					name: user.name,
					email: user.email,
					phone: user.phone.toString(),
					avatar: user.avatar.url
				}}
				onSubmit={handleSubmit}
				validationSchema={updateProfileSchema}
			>
				{({
					handleSubmit,
					handleChange,
					errors,
					touched,
					setFieldTouched,
					setFieldValue,
					values }) => <View>
						<TextInput
							label={"Name"}
							mode="outlined"
							error={errors.name}
							value={values.name}
							onChangeText={handleChange("name")}
							onBlur={() => setFieldTouched("name")}
							theme={{ colors: { primary: 'orange', text: 'orange' } }}
						/>
						<Text style={{color: 'gray'}}>Current Name: {user.name}</Text>
						<ErrorText error={errors.name} touched={touched.name} />
						<TextInput
							label={"Email"}
							mode="outlined"
							error={errors.email}
							value={values.email}
							onChangeText={handleChange("email")}
							onBlur={() => setFieldTouched("email")}
							theme={{ colors: { primary: 'orange', text: 'orange' } }}
						/>
						<Text style={{color: 'gray'}}>Current Name: {user.email}</Text>
						<ErrorText error={errors.email} touched={touched.email} />
						<TextInput
							label={"Phone"}
							mode="outlined"
							error={errors.phone}
							value={values.phone}
							onChangeText={handleChange("phone")}
							onBlur={() => setFieldTouched("phone")}
							theme={{ colors: { primary: 'orange', text: 'orange' } }}
						/>
						<Text style={{color: 'gray'}}>Current Name: {user.phone}</Text>
						<ErrorText error={errors.phone} touched={touched.phone} />
						<View style={styles.imageField}>
							<TouchableOpacity onPress={() => handleImage(setFieldValue)}>
								<Image source={{ uri: values.avatar }} style={styles.image} />
							</TouchableOpacity>
							<Text style={styles.imageText}>Select An Image</Text>
							<TouchableOpacity style={styles.choose} onPress={() => handleImage(setFieldValue)}>
								<Text style={styles.chooseText}>Choose</Text>
							</TouchableOpacity>
						</View>
						<ErrorText error={errors.avatar} touched={touched.avatar} />
						<TouchableOpacity style={styles.btn} onPress={handleSubmit}>
							<Text style={styles.btnText}>Update Profile</Text>
						</TouchableOpacity>
					</View>}
			</Formik>
		</View>
	)
}

const styles = StyleSheet.create({
	main: {
		height: '100%',
		backgroundColor: 'white',
		padding: 10
	},
	btn: {
		backgroundColor: 'orange',
		padding: 15,
		marginTop: 20
	},
	btnText: {
		textAlign: 'center',
		color: 'white',
		fontWeight: 'bold'
	},
	imageField: {
		display: 'flex',
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center',
		padding: 10
	},
	image: {
		width: 60,
		height: 60,
		borderRadius: 70,
		borderWidth: 1,
		borderColor: 'orange',
	},
	imageText: {
		marginLeft: 20,
		color: 'black'
	},
	choose: {
		backgroundColor: 'gray',
		padding: 15,
		borderRadius: 15,
		marginLeft: 20
	},
	chooseText: {
		color: 'white'
	},
	loader: {
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center',
		height: '100%'
	},
	img: {
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center',
		height: 150,
		width: 150,
		marginLeft: '30%'
	},
	header: {
		textAlign: 'center',
		fontSize: 22,
		fontWeight: 'bold',
		color: 'black',
		margin: 20
	}
})

export default UpdateProfile;
