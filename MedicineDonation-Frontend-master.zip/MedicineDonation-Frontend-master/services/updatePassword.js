import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { BACKEND } from "@env";

const updatePassword = async(oldPassword, newPassword) => {
    try {
        const token = await AsyncStorage.getItem("medicineToken");
        const {data} = await axios.put(
            BACKEND+'/password/update',
            {oldPassword,password: newPassword},
            {headers: {Cookie: "token="+token}}
            );
        return [data, null]
    } catch (error) {
        return [null, error]
    }
}

export default updatePassword;