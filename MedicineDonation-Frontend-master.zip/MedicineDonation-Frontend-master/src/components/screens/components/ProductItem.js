import {StyleSheet, Text, View, TouchableOpacity} from 'react-native';
import React from 'react';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {Card, Title} from 'react-native-paper';
const ProductItem = ({product, navigation}) => {
  const Stars = () => {
    let stars = [];
    for (let i = 0; i < product.ratings; i++) {
      stars.push(
        <View>
          <Icon name="star" size={30} color="yellow" />
        </View>,
      );
    }
    return (
      <View
        style={{
          display: 'flex',
          flexDirection: 'row',
          alignItems: 'center',
        }}>
        {stars.map((item, key) => (
          <View key={key}>
            <Icon name="star" size={30} color="yellow" />
          </View>
        ))}
        {product.reviews.length ? (
          <Text>{product.reviews.length} Reviews</Text>
        ) : null}
      </View>
    );
  };
  return (
    <View>
      <Card style={styles.card}>
        <Card.Cover source={{uri: product.images[0].url}} />

        <Card.Content>
          <Title style={styles.text}>{product.name}</Title>
          <Stars />
          <Text
            style={{
              margin: 5,
              fontWeight: 'bold',
              color: 'black',
              fontSize: 15,
            }}>
            Status:{' '}
            {product.stock > 0 ? (
              <Text style={{color: 'green', fontWeight: 'bold'}}>IN STOCK</Text>
            ) : (
              <Text style={{color: 'red', fontWeight: 'bold'}}>
                Out of Stock
              </Text>
            )}
          </Text>
          <Text style={styles.text}>
            Expiry Date:{' '}
            {new Date(product.date).getFullYear() +
              '-' +
              new Date(product.date).getDay() +
              '-' +
              new Date(product.date).getMonth()}
          </Text>
        </Card.Content>
        <Card.Actions>
          <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate("MedicineDetail",{_id: product._id})}>
            <Text style={{color: 'white', textAlign: 'center'}}>
              View Details
            </Text>
          </TouchableOpacity>
        </Card.Actions>
      </Card>
    </View>
  );
};

export default ProductItem;

const styles = StyleSheet.create({
  text: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    margin: 10,
  },
  card: {
    margin: 20,
    backgroundColor: 'whitesmoke',
  },
  btn: {
    padding: 10,
    backgroundColor: 'orange',
    justifyContent: 'center',
    textAlign: 'center',
    left: 55,
    width: 200,
    borderRadius: 10,
    margin: 10,
  },
});
