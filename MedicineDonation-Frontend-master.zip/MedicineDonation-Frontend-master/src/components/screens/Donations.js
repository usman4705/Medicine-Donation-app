import { StyleSheet, Text, View, ScrollView, TouchableOpacity } from 'react-native'
import React, { useState, useRef, useEffect, useContext } from 'react'
import getDonations from '../../../services/getDonations';
import Icon from "react-native-vector-icons/MaterialIcons";
import { FAB } from 'react-native-paper';
import deleteDonation from '../../../services/deleteDonation';
import SweetAlert from 'react-native-sweet-alert';

const Donations = ({ navigation }) => {
	const [donations, setDonations] = useState([]);
	const fetchDonations = useRef(null);

	fetchDonations.current = async () => {
		const [data, error] = await getDonations();
		if (data) setDonations(data.donation);
		if (error) console.log(error.response)
	}

	useEffect(() => {
		fetchDonations.current();
	}, [])

	const handleDelete = async(id) => {
		const temp = donations.filter(item => item._id !== id);
		setDonations(temp);
		SweetAlert.showAlertWithOptions({
			title: 'Successfully Deleted',
			subTitle: '',
			confirmButtonTitle: 'OK',
			confirmButtonColor: 'red',
			otherButtonTitle: 'Cancel',
			otherButtonColor: '#dedede',
			style: 'success',
			cancellable: true,
		  });
		await deleteDonation(id)
	}

	const handleUpdate = (donation) => {
		navigation.navigate("Update Medicines", { donation });
	}

	return (
		<View style={{ height: '100%', position: 'relative', padding: 20, backgroundColor: 'white' }}>
			<Text style={{ textAlign: 'center', fontWeight: 'bold', color: 'black', fontSize: 22, marginBottom: 20 }}>Donations</Text>
			<TouchableOpacity onPress={() => fetchDonations.current()} style={{ backgroundColor: 'orange', padding: 20, borderRadius: 10 }}>
				<Text style={{ color: 'white' }}>Refresh</Text>
			</TouchableOpacity>
			<FAB
				style={{
					position: 'absolute',
					bottom: 20,
					right: 50,
					backgroundColor: 'orange',
					zIndex: 9999
				}}
				icon="plus"
				onPress={() => navigation.navigate("DonateMoney")}
				color="white"
			/>
			<ScrollView style={styles.main}>
				{donations.map(donation => <View key={donation._id}>
					<Text style={styles.lightgray}>ID# {donation._id}</Text>
					<Text style={styles.white}>Medicine: {donation.name}</Text>
					<Text style={styles.lightgray}>Donor: {donation.seller}</Text>
					<Text style={styles.white}>Stock: {donation.stock}</Text>
					<View style={styles.btnContainer}>
						<TouchableOpacity onPress={() => handleUpdate(donation)} style={[styles.btn, { backgroundColor: 'dodgerblue' }]}>
							<Icon name='edit' size={20} color="white" />
						</TouchableOpacity>
						<TouchableOpacity onPress={() => handleDelete(donation._id)} style={[styles.btn, { backgroundColor: '#dc3545' }]}>
							<Icon name='delete' size={20} color="white" />
						</TouchableOpacity>
					</View>
				</View>)}
			</ScrollView>
		</View>
	)
}

const styles = StyleSheet.create({
	main: {
		backgroundColor: 'white',
		height: '100%'
	},
	btnContainer: {
		display: 'flex',
		flexDirection: 'row',
		marginBottom: 20,
		justifyContent: 'center'
	},
	btn: {
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center',
		borderRadius: 10,
		width: 40,
		padding: 10,
		marginRight: 10
	},
	lightgray: {
		backgroundColor: 'lightgray',
		padding: 10,
		fontWeight: 'bold'
	},
	white: {
		padding: 10,
		color: 'black'
	}
})

export default Donations