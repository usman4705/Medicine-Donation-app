import axios from 'axios';
import { BACKEND } from "@env";

const getMedicineById = async(id) => {
  try {
    const {data} = await axios.get(
        `${BACKEND}/product/${id}`)
    return [data, null]
  } catch (error) {
    return [null, error]
  }
}

export default getMedicineById