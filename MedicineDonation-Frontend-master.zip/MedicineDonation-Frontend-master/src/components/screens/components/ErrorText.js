import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ErrorText = ({touched, error}) => {
    if(!touched) return null;
    return (
    <View style={styles.main}>
      <Text style={styles.text}>{error}</Text>
    </View>
  )
}

const styles = StyleSheet.create({
    main: {
        width: '100%'
    },
    text: {
        color: 'brown',
    }
})

export default ErrorText;
