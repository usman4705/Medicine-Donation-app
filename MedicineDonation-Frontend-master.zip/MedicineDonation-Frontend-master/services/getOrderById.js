import axios from "axios";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {BACKEND} from "@env";

const getOrderById = async(id) => {
    try {
        const token = await AsyncStorage.getItem("medicineToken")
        if(!token) return;
        const {data} = await axios.get(
            `${BACKEND}/order/`+id,
            {headers: { Cookie: "token="+token }}
        )
        return [data, null]
    } catch (error) {
        return [null, error]
    }
}

export default getOrderById;