import { StyleSheet, Text, View, Image, TouchableOpacity, ActivityIndicator } from 'react-native'
import React, {useContext, useState} from 'react';
import {Formik} from "formik";
import ErrorText from './components/ErrorText';
import {TextInput} from 'react-native-paper'
import { CartContext } from '../../../global/CartContext';
import placeOrder from '../../../services/placeOrder';
import SweetAlert from 'react-native-sweet-alert';
import sendEmail from '../../../services/sendEmail';
import { UserContext } from '../../../global/UserContext';

const Checkout = ({navigation}) => {
	const [cart] = useContext(CartContext);
	const [user] = useContext(UserContext);
	const [loading, setLoading] = useState(false);

	const handleSubmit = async values => {
		setLoading(true)
		let orderItems = [];
		cart.map(itm => orderItems.push({
			image: itm.images[0].url, 
			quantity: itm.quantity,
			name: itm.name,
			product: itm._id
		}))
		const [data, error] = await placeOrder(orderItems, values)
		await sendEmail(user.email);
		if(error){
			setLoading(false)
			return SweetAlert.showAlertWithOptions({
				title: 'Place Order Failed',
				subTitle: 'Failed to Place Order',
				confirmButtonTitle: 'OK',
				confirmButtonColor: 'red',
				otherButtonTitle: 'Cancel',
				otherButtonColor: '#dedede',
				style: 'danger',
				cancellable: true,
			});
		}
		SweetAlert.showAlertWithOptions({
			title: 'Successfully Place Order',
			subTitle: '',
			confirmButtonTitle: 'OK',
			confirmButtonColor: 'red',
			otherButtonTitle: 'Cancel',
			otherButtonColor: '#dedede',
			style: 'success',
			cancellable: true,
		});
		setLoading(false);
	}

	if(loading) return <View style={[styles.main,{display: 'flex',justifyContent:'center',alignItems:'center'}]}>
		<ActivityIndicator color="orange" size={40} />
	</View>
	return (
		<View style={styles.main}>
			<Text style={styles.header}>Place Order</Text>
			<Formik
				initialValues={{
					address: '',
					city: '',
					phoneNo: '',
					country: '',
					postalCode: ''
				}}
				onSubmit={handleSubmit}
			
			>
				{({
					handleSubmit,
					handleChange,
					errors,
					touched,
					setFieldTouched,
					setFieldValue,
					values }) => <View>
						<TextInput
							label={"Address"}
							mode="outlined"
							error={errors.address}
							onChangeText={handleChange("address")}
							onBlur={() => setFieldTouched("address")}
							theme={{ colors: { primary: 'orange', text: 'orange' } }}
						/>
						<ErrorText error={errors.address} touched={touched.address} />
						<TextInput
							label={"City"}
							mode="outlined"
							error={errors.email}
							onChangeText={handleChange("city")}
							onBlur={() => setFieldTouched("city")}
							theme={{ colors: { primary: 'orange', text: 'orange' } }}
						/>
						<ErrorText error={errors.city} touched={touched.city} />
						<TextInput
							label={"Phone"}
							mode="outlined"
							error={errors.phoneNo}
							onChangeText={handleChange("phoneNo")}
							onBlur={() => setFieldTouched("phoneNo")}
							theme={{ colors: { primary: 'orange', text: 'orange' } }}
						/>
						<ErrorText error={errors.phoneNo} touched={touched.phoneNo} />
						<TextInput
							label={"Postal Code"}
							mode="outlined"
							error={errors.postalCode}
							onChangeText={handleChange("postalCode")}
							onBlur={() => setFieldTouched("postalCode")}
							theme={{ colors: { primary: 'orange', text: 'orange' } }}
						/>
						<ErrorText error={errors.postalCode} touched={touched.postalCode} />
						<TextInput
							label={"Country"}
							mode="outlined"
							error={errors.postalCode}
							onChangeText={handleChange("country")}
							onBlur={() => setFieldTouched("country")}
							theme={{ colors: { primary: 'orange', text: 'orange' } }}
						/>
						<ErrorText error={errors.country} touched={touched.country} />
						<TouchableOpacity style={styles.btn} onPress={handleSubmit}>
							<Text style={styles.btnText}>Place Order</Text>
						</TouchableOpacity>
					</View>}
			</Formik>
		</View>
	)
}

const styles = StyleSheet.create({
	main: {
		height: '100%',
		backgroundColor: 'white',
		padding: 10
	},
	btn: {
		backgroundColor: 'orange',
		padding: 15,
		marginTop: 20
	},
	btnText: {
		textAlign: 'center',
		color: 'white',
		fontWeight: 'bold'
	},
	imageField: {
		display: 'flex',
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems:'center',
		padding: 10
	},
	image: {
		width: 60,
		height: 60,
		borderRadius: 70,
		borderWidth: 1,
		borderColor: 'orange',
	},
	imageText: {
		marginLeft: 20,
		color: 'black'
	},
	choose: {
		backgroundColor: 'gray',
		padding: 15,
		borderRadius: 15,
		marginLeft: 20
	},
	chooseText: {
		color:'white'
	},
	loader: {
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center',
		height: '100%'
	},
  img: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: 150,
    width: 150,
		marginLeft: '30%'
  },
	header: {
		textAlign: 'center',
		fontSize: 22,
		fontWeight: 'bold',
		color: 'black',
		margin: 20
	}
})

export default Checkout;
