import { StyleSheet, Text, View, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native'
import React, { useContext, useState, useRef, useEffect } from 'react';
import getOrders from '../../../services/getOrders';

const Orders = ({navigation}) => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const fetchOrders = useRef(null);

  fetchOrders.current = async() => {
    setLoading(true);
    const [data, error] = await getOrders();
    if(error) return setLoading(false);
    setOrders(data.orders);
    setLoading(false);
  } 

  useEffect(()=>{
    fetchOrders.current();
  },[])

  if(loading) return <View style={{width: '100%', height: '100%', display: 'flex',justifyContent: 'center',alignItems:'center'}}>
  <ActivityIndicator size={"large"} color='orange' />
</View>
  return (
    <ScrollView style={styles.main}>
      <Text style={styles.header}>Orders</Text>
      {orders.reverse().map( order => <TouchableOpacity onPress={() => navigation.navigate("OrderDetails",{id: order._id})} style={styles.order}>
        <Text style={styles.text}>Order ID: {order._id}</Text>
        <Text style={styles.text}>Medicine Name: {order.orderItems.map(item => item.name+", ")}</Text>
        <Text style={styles.text}>Status: {order.orderStatus}</Text>
        <Text style={styles.text}>Number of Items: {order.orderItems.length}</Text>
      </TouchableOpacity> )}
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  main: {
    backgroundColor: 'white',
    height: '100%',
    padding: 10
  },
  header: {
    fontSize: 26,
    color: 'black',
    textAlign: 'center',
    fontWeight: 'bold'
  },
  order: {
    backgroundColor: 'orange',
    padding: 10,
    borderRadius: 10,
    margin: 10
  },
  text: {
    color: 'black',
    fontSize: 18
  }
})

export default Orders