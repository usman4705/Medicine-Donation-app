import {
  StyleSheet,
  Text,
  View,
  Image,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import MEDICINE from '../../../assets/medicinedonation-logo.png';
import Icon from 'react-native-vector-icons/MaterialIcons';
import axios from 'axios';
import React, { useState, useEffect } from 'react';
import ProductItem from './components/ProductItem';
import { TextInput, TouchableRipple } from "react-native-paper"
import { BACKEND } from "@env";
import Search from './components/Search';

const ProductScreen = ({ navigation }) => {
  const [products, setProducts] = useState({ allproducts: [] });
  const [loading, setLoading] = useState(false);
  const [texts, setTexts] = useState("");
  const [mapProducts, setMapProducts] = useState([]);
  const [displayProducts, setDisplayProducts] = useState([]);
  const [page, setPage] = useState(1);

  const getMedicines = async () => {
    try {
      setLoading(true);
      const { data } = await axios.get(
        `${BACKEND}/products/?page=${page}`,
      );
      if (data) setProducts(data);
      setMapProducts([...mapProducts, ...data.allproducts]);
      setDisplayProducts([...mapProducts, ...data.allproducts])
      setLoading(false);
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
  };
  useEffect(() => {
    getMedicines();
  }, [page]);

  const handlePage = () => {
    // if (products.filteredProductsCount === products.resperpage && displayProducts.length === products.resperpage)
      setPage(prev => prev + 1);
  };

  const handleSearch = (text) => {
    let temp = displayProducts.filter(prod => prod.name.indexOf(text) !== -1)
    setDisplayProducts(temp);
  }

  const handleReset = () => setDisplayProducts(mapProducts);
  

  return (
    <View>
      <FlatList
        data={displayProducts}
        refreshing={loading}
        renderItem={({ item }) => <ProductItem navigation={navigation} product={item} />}
        ListHeaderComponent={() => (
          <View style={styles.product}>
            <Image style={styles.img} source={MEDICINE} />
            <Text style={styles.text}>Remagining access for those in need</Text>
            <Text style={styles.text}>
              LATEST MEDICINES{' '}
              <Icon name="medical-services" size={20} color="#000950" />
            </Text>
            <Search handleReset={handleReset} handleSearch={handleSearch} />
          </View>
        )}
        onEndReached={handlePage}
        onRefresh={()=>{setPage(1);getMedicines()}}
        ListFooterComponent={() =>
          loading && (
            <View>
              <ActivityIndicator size="large" color="orange" />
            </View>
          )
        }
      />
      {/* {products.allproducts.map(item => (
        <ProductItem product={item} />
      ))} */}
    </View>
  );
};

export default ProductScreen;

const styles = StyleSheet.create({
  img: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: 150,
    width: 150,
  },
  product: {
    margin: 20,

    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'black',
    margin: 10,
  },
  card: {
    margin: 20,
    backgroundColor: 'whitesmoke',
  },
  btn: {
    padding: 10,
    backgroundColor: 'orange',
    justifyContent: 'center',
    textAlign: 'center',
    left: 55,
    width: 200,
    borderRadius: 10,
    margin: 10,
  },
});
