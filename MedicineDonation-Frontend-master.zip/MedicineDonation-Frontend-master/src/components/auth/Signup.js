import {
  StyleSheet,
  Text,
  View,
  TextInput,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import {useFormik} from 'formik';
import IconMaterial from 'react-native-vector-icons/MaterialCommunityIcons';
import * as Yup from 'yup';
import axios from 'axios';
import SweetAlert from 'react-native-sweet-alert';
import MEDICINE from '../../../assets/medicinedonation-logo.png';
import {launchImageLibrary} from 'react-native-image-picker';
import getFileExtension from '../utils/getFileExtension';
import React, {useState} from 'react';
import { BACKEND } from "@env";

const Signup = ({navigation}) => {
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const uploadImage = async () => {
    const {didCancel, assets} = await launchImageLibrary({
      mediaType: 'photo',
      includeBase64: true,
    });
    if (didCancel) return;
    const extension = getFileExtension(assets[0].fileName);
    let base64Image = `data:image/${extension};base64,` + assets[0].base64;
    setImage(base64Image);
    console.log(base64Image.slice(0, 30));
  };
  const validationSchema = Yup.object().shape({
    name: Yup.string().min(3, 'Its too short').required('Required'),
    email: Yup.string().email('Enter valid email').required('Required'),
    password: Yup.string()
      .min(8, 'Password minimum length should be 8')
      .required('Required'),
    phone: Yup.number().min(11, 'Its too short').required('Required'),
  });
  const formik = useFormik({
    initialValues: {
      name: '',
      email: '',
      password: '',
      phone: '',
    },
    validationSchema: validationSchema,
    onSubmit: async values => {
      const formData = new FormData();
      formData.append('name', values.name);
      formData.append('email', values.email);
      formData.append('password', values.password);
      formData.append('phone', values.phone);
      formData.append('avatar', image);
      try {
        setLoading(true);
        const {data} = await axios.post(
          BACKEND+'/register',
          {
            name: values.name,
            email: values.email,
            password: values.password,
            phone: values.phone,
            avatar: image,
          },
        );
        console.log(data);
        SweetAlert.showAlertWithOptions({
          title: 'Successfully Registered',
          subTitle: '',
          confirmButtonTitle: 'OK',
          confirmButtonColor: 'red',
          otherButtonTitle: 'Cancel',
          otherButtonColor: '#dedede',
          style: 'success',
          cancellable: true,
        });
        setLoading(false);
      } catch (error) {
        console.log(error.response);
        setLoading(false);
        SweetAlert.showAlertWithOptions({
          title: 'Credentials Error',
          subTitle: '',
          confirmButtonTitle: 'OK',
          confirmButtonColor: 'red',
          otherButtonTitle: 'Cancel',
          otherButtonColor: '#dedede',
          style: 'danger',
          cancellable: true,
        });
      }
    },
  });
  return (
    <ScrollView>
      <View style={styles.article}>
        <Image style={styles.img} source={MEDICINE} />
        <View style={{margin: 20}}>
          <Text style={{fontSize: 30, color: 'black', fontWeight: 'bold'}}>
            SIGN UP
          </Text>
        </View>

        <TextInput
          style={styles.input}
          placeholder="Enter Username"
          value={formik.values.name}
          onChangeText={formik.handleChange('name')}
        />
        {formik.errors.name && (
          <Text style={{fontSize: 10, color: 'red'}}>{formik.errors.name}</Text>
        )}

        <TextInput
          style={styles.input}
          placeholder="Enter Email"
          value={formik.values.email}
          onChangeText={formik.handleChange('email')}
        />
        {formik.errors.email && (
          <Text style={{fontSize: 10, color: 'red'}}>
            {formik.errors.email}
          </Text>
        )}

        <TextInput
          style={styles.input}
          placeholder="Enter Password"
          value={formik.values.password}
          onChangeText={formik.handleChange('password')}
        />
        {formik.errors.password && (
          <Text style={{fontSize: 10, color: 'red'}}>
            {formik.errors.password}
          </Text>
        )}

        <TextInput
          style={styles.input}
          placeholder="Enter Contact Number"
          value={formik.values.phone}
          onChangeText={formik.handleChange('phone')}
        />
        {formik.errors.phone && (
          <Text style={{fontSize: 10, color: 'red'}}>
            {formik.errors.phone}
          </Text>
        )}

        {image != null ? (
          <TouchableOpacity>
            <Image style={{width: 100, height: 100}} source={{uri: image}} />
          </TouchableOpacity>
        ) : null}
        <TouchableOpacity onPress={uploadImage} style={styles.btn}>
          <Text style={{color: 'white'}}>
            <IconMaterial name="file-image" size={15} />
            Select Avatar
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.btn} onPress={formik.handleSubmit}>
          <Text style={{color: 'white'}}>SIGN UP</Text>
        </TouchableOpacity>
        <Text
          onPress={() => navigation.navigate('Login')}
          style={{textDecorationLine: 'underline', color: 'blue'}}>
          Already Register? Login
        </Text>
      </View>
    </ScrollView>
  );
};

export default Signup;

const styles = StyleSheet.create({
  article: {
    margin: 20,

    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    flex: 1,
    borderRadius: 20,
    height: 50,
    width: '70%',
    margin: 12,
    backgroundColor: 'lightgray',
    padding: 10,
  },
  btn: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#5995fd',
    height: 40,
    width: 150,
    borderRadius: 12,
    margin: 15,
  },
  img: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: 150,
    width: 150,
  },
  sectionStyle: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderWidth: 0.5,
    borderColor: 'gray',
    height: 40,
    borderRadius: 12,
    margin: 10,
  },
  imageStyle: {
    padding: 10,
    margin: 5,
    height: 25,
    width: 25,
    resizeMode: 'stretch',
    alignItems: 'center',
  },
});
